## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(tvem)
library(refund)
library(boot)
library(funmediation)

## -----------------------------------------------------------------------------
set.seed(123);
info1 <- simulate_funmediation_example();
the_data <- info1$dataset;

## -----------------------------------------------------------------------------
model1 <- funmediation(data=the_data,
                             treatment=X,
                             mediator=M,
                             outcome=Y,
                             id=subject_id,
                             time=t,
                             nboot=19);			

## -----------------------------------------------------------------------------
print(model1);
plot(model1);

